using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace KongZuo
{
    /// <summary>跨场景保留的最小剧情状态容器。正式存档系统由后续版本接入。</summary>
    [DisallowMultipleComponent]
    public sealed class KZGameSession : MonoBehaviour
    {
        public static KZGameSession Instance { get; private set; }

        private readonly HashSet<string> flags = new HashSet<string>(StringComparer.Ordinal);
        public event Action<string> FlagAdded;
        public string CurrentSceneName { get; private set; }

        public static KZGameSession EnsureExists()
        {
            if (Instance != null) return Instance;

            KZGameSession existing = FindFirstObjectByType<KZGameSession>();
            if (existing != null) return existing;

            return new GameObject("KZ_GameSession").AddComponent<KZGameSession>();
        }

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }

            Instance = this;
            DontDestroyOnLoad(gameObject);
            CurrentSceneName = SceneManager.GetActiveScene().name;
            SceneManager.sceneLoaded += OnSceneLoaded;
        }

        private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
        {
            CurrentSceneName = scene.name;
        }

        private void OnDestroy()
        {
            if (Instance != this) return;
            SceneManager.sceneLoaded -= OnSceneLoaded;
            Instance = null;
        }

        public bool HasFlag(string flag)
        {
            return !string.IsNullOrWhiteSpace(flag) && flags.Contains(flag);
        }

        public bool TryAddFlag(string flag)
        {
            if (string.IsNullOrWhiteSpace(flag)) return false;
            if (!flags.Add(flag)) return false;
            FlagAdded?.Invoke(flag);
            return true;
        }


        // 用于恢复中断的演出，不清除其他已经收集的线索。
        public bool RemoveFlag(string flag)
        {
            return !string.IsNullOrWhiteSpace(flag) && flags.Remove(flag);
        }

        public string[] GetFlagsSorted()
        {
            string[] result = new string[flags.Count];
            flags.CopyTo(result);
            Array.Sort(result, StringComparer.Ordinal);
            return result;
        }

        public void ResetSession()
        {
            flags.Clear();
        }
    }
}
