#if UNITY_EDITOR
using System;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

// Repeatable local integration of the art team's model into the playable P0 scenes.
// Existing colliders, triggers, interactables, cameras, and story components remain intact.
public static class KZMergedArtSetup
{
    private const string ArtRoot = "Assets/KongZuo/ZhaiModel/KongZuo_OperaHouse_P2";
    private const string PrefabPath = ArtRoot + "/Generated/PF_KZ_P2_OperaHouse_All.prefab";
    private const string ArtInstanceName = "KZ_OperaHouse_P2_Integrated_Visuals";

    [MenuItem("Tools/空座/整合/将戏楼美术接入序章和第一章")]
    public static void Integrate()
    {
        KZOperaHouseP2Preview.GenerateInterior();
        KZOperaHouseP2Preview.GenerateExterior();
        AssetDatabase.Refresh();

        GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>(PrefabPath);
        if (prefab == null)
            throw new InvalidOperationException("Art prefab was not generated: " + PrefabPath);

        IntegrateScene("Assets/KongZuo/Scenes/01_Prologue.unity", prefab);
        IntegrateScene("Assets/KongZuo/Scenes/02_Chapter01.unity", prefab);
        AssetDatabase.SaveAssets();
        Debug.Log("KZ_ART_INTEGRATION_OK: playable prologue and chapter 1 now contain the P2 opera-house visuals.");
    }

    // Complete the import once, after Unity has finished bringing in the OBJ assets.
    [InitializeOnLoad]
    private static class FirstOpenIntegration
    {
        private const string SessionKey = "KZ_Art_Integration_Attempted_This_Session";

        static FirstOpenIntegration()
        {
            EditorApplication.delayCall += TryIntegrate;
        }

        private static void TryIntegrate()
        {
            if (EditorApplication.isCompiling || EditorApplication.isUpdating)
            {
                EditorApplication.delayCall += TryIntegrate;
                return;
            }
            if (SessionState.GetBool(SessionKey, false)) return;
            SessionState.SetBool(SessionKey, true);

            string scenePath = Path.Combine(Path.GetDirectoryName(Application.dataPath), "Assets/KongZuo/Scenes/01_Prologue.unity");
            if (!File.Exists(scenePath)) return;
            if (File.ReadAllText(scenePath).Contains(ArtInstanceName)) return;
            try
            {
                Integrate();
            }
            catch (Exception error)
            {
                Debug.LogError("空座美术自动整合未完成。可用 Tools/空座/整合 菜单重试。\n" + error);
            }
        }
    }

    private static void IntegrateScene(string path, GameObject prefab)
    {
        Scene scene = EditorSceneManager.OpenScene(path, OpenSceneMode.Single);
        bool hasArt = false;
        int hiddenObjects = 0;
        foreach (GameObject root in scene.GetRootGameObjects())
        {
            if (root.name == ArtInstanceName)
            {
                hasArt = true;
                continue;
            }
            if (!IsGreyboxVisual(root.name)) continue;
            foreach (MeshRenderer renderer in root.GetComponentsInChildren<MeshRenderer>(true))
            {
                if (!renderer.enabled) continue;
                renderer.enabled = false;
                hiddenObjects++;
            }
        }

        if (!hasArt)
        {
            GameObject art = (GameObject)PrefabUtility.InstantiatePrefab(prefab, scene);
            if (art == null) throw new InvalidOperationException("Could not instantiate art prefab in " + path);
            art.name = ArtInstanceName;
            art.transform.position = Vector3.zero;
            art.transform.rotation = Quaternion.identity;
            art.transform.localScale = Vector3.one;
        }

        EditorSceneManager.MarkSceneDirty(scene);
        if (!EditorSceneManager.SaveScene(scene)) throw new InvalidOperationException("Could not save " + path);
        Debug.Log("KZ_ART_SCENE_OK: " + path + "; hidden greybox renderers=" + hiddenObjects);
    }

    private static bool IsGreyboxVisual(string name)
    {
        if (name.StartsWith("第", StringComparison.Ordinal) && name.Contains("排_") && name.EndsWith("座", StringComparison.Ordinal)) return true;
        if (name.StartsWith("侧间隔墙_", StringComparison.Ordinal)) return true;
        if (name.StartsWith("侧房间后墙", StringComparison.Ordinal)) return true;
        switch (name)
        {
            case "1F_地面":
            case "西立面":
            case "东立面":
            case "北端背景":
            case "正门西侧墙":
            case "正门东侧墙":
            case "门楣":
            case "室外石阶限位":
            case "戏台台面":
            case "戏台门楣":
            case "红幕":
            case "舞台西柱":
            case "舞台东柱":
            case "下台阶_高":
            case "下台阶_中":
            case "下台阶_低":
                return true;
            default:
                return false;
        }
    }
}
#endif
