using UnityEngine;

namespace KongZuo
{
    [DisallowMultipleComponent]
    public sealed class KZInteractor : MonoBehaviour
    {
        [SerializeField] private Camera viewCamera;
        [SerializeField, Min(0.5f)] private float reach = 3.3f;
        public void SetCamera(Camera camera) { viewCamera = camera; }

        private void Awake()
        {
            if (viewCamera == null) viewCamera = GetComponentInChildren<Camera>();
        }

        private void Update()
        {
            if (KZHud.IsModal || Cursor.lockState != CursorLockMode.Locked ||
                (KZStoryDirector.Current != null && KZStoryDirector.Current.IsBusy))
            {
                KZHud.SetHint("");
                return;
            }

            KZInteractable item = null;
            if (viewCamera != null &&
                Physics.Raycast(viewCamera.transform.position, viewCamera.transform.forward,
                    out RaycastHit hit, reach, ~0, QueryTriggerInteraction.Ignore))
            {
                item = hit.collider.GetComponentInParent<KZInteractable>();
            }

            KZHud.SetHint(item == null ? "" : "[E] " + item.DisplayName);
            if (item != null && KZInput.ConsumeInteract()) item.Interact();
        }
    }
}
