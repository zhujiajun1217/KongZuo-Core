using UnityEngine;

namespace KongZuo
{
    [RequireComponent(typeof(CharacterController))]
    [DisallowMultipleComponent]
    public sealed class KZFirstPersonPlayer : MonoBehaviour
    {
        [SerializeField] private Transform eye;
        [SerializeField, Min(0f)] private float walkSpeed = 3.5f;
        [SerializeField, Min(0f)] private float sensitivity = 1f;
        [SerializeField] private float gravity = -19.6f;

        private CharacterController controller;
        private float pitch;
        private float verticalSpeed;
        private bool freezeWalking;

        public void SetCameraPivot(Transform pivot) { eye = pivot; }
        public void SetFreezeWalking(bool frozen) { freezeWalking = frozen; }

        public void Teleport(Vector3 position, Quaternion facing)
        {
            if (controller == null) controller = GetComponent<CharacterController>();
            controller.enabled = false;
            transform.SetPositionAndRotation(position, facing);
            controller.enabled = true;
            pitch = 0f;
            verticalSpeed = 0f;
            if (eye != null) eye.localRotation = Quaternion.identity;
        }

        private void Awake()
        {
            controller = GetComponent<CharacterController>();
            if (eye == null)
            {
                Camera cameraChild = GetComponentInChildren<Camera>();
                if (cameraChild != null) eye = cameraChild.transform;
            }
        }

        private void Start()
        {
            KZGameSession.EnsureExists();
            SetCursor(true);
        }

        private void OnDisable() { SetCursor(false); }

        private void Update()
        {
            if (KZHud.IsModal) return;

            if (KZInput.Escape()) SetCursor(Cursor.lockState != CursorLockMode.Locked);
            else if (Cursor.lockState != CursorLockMode.Locked && KZInput.Click()) SetCursor(true);

            if (Cursor.lockState != CursorLockMode.Locked) return;

            Vector2 look = KZInput.Look() * sensitivity;
            transform.Rotate(Vector3.up, look.x, Space.Self);
            pitch = Mathf.Clamp(pitch - look.y, -82f, 82f);
            if (eye != null) eye.localRotation = Quaternion.Euler(pitch, 0f, 0f);

            // 残响时允许观察，但不允许移动；文档和谜题窗口期间完全暂停操作。
            if (freezeWalking) return;

            Vector2 axis = KZInput.Move();
            Vector3 direction = transform.right * axis.x + transform.forward * axis.y;
            if (controller.isGrounded && verticalSpeed < 0f) verticalSpeed = -1.5f;
            verticalSpeed += gravity * Time.deltaTime;
            controller.Move((direction * walkSpeed + Vector3.up * verticalSpeed) * Time.deltaTime);
        }

        private static void SetCursor(bool locked)
        {
            Cursor.lockState = locked ? CursorLockMode.Locked : CursorLockMode.None;
            Cursor.visible = !locked;
        }
    }
}
