using System;
using UnityEngine;

namespace KongZuo
{
    // 第四周测试UI。使用IMGUI，不额外依赖TMP和Canvas；美术入场后可整体替换。
    [DisallowMultipleComponent]
    public sealed class KZHud : MonoBehaviour
    {
        public string chapterName = "《空座》";
        private static KZHud current;
        private static string hint = "";

        private string toast = "";
        private string pageTitle;
        private string pageBody;
        private Action pageClosed;
        private bool journalOpen;
        private bool puzzleOpen;
        private KZSeatPuzzle puzzle = new KZSeatPuzzle();
        private Func<bool> cluesKnown;
        private Action puzzleSolved;
        private string puzzleFeedback = "";
        private Vector2 scroll;
        private float toastUntil;

        public static bool IsModal
        {
            get { return current != null &&
                (current.pageTitle != null || current.journalOpen || current.puzzleOpen); }
        }

        private void Awake() { current = this; }
        private void OnDestroy()
        {
            if (current == this) { current = null; hint = ""; }
        }

        public static void SetHint(string value) { hint = value ?? ""; }

        public static void ShowToast(string text, float seconds = 5f)
        {
            if (current == null) { Debug.Log("[空座] " + text); return; }
            current.toast = text ?? "";
            current.toastUntil = Time.unscaledTime + seconds;
        }

        public static void ShowPage(string title, string body, Action onClose = null)
        {
            if (current == null)
            {
                Debug.Log("[空座] " + title + ": " + body);
                if (onClose != null) onClose();
                return;
            }
            current.journalOpen = false;
            current.puzzleOpen = false;
            current.pageTitle = title ?? "资料检视";
            current.pageBody = body ?? "";
            current.scroll = Vector2.zero;
            current.pageClosed = onClose;
        }

        public static void ShowPuzzle(Func<bool> isReady, Action onSolved)
        {
            if (current == null) { Debug.LogWarning("缺少 KZHud。"); return; }
            current.journalOpen = false;
            current.pageTitle = null;
            current.pageBody = null;
            current.puzzleOpen = true;
            current.cluesKnown = isReady;
            current.puzzleSolved = onSolved;
            current.puzzleFeedback = "根据宣传册、合照与票根填写座次。";
        }

        private void Update()
        {
            if (pageTitle != null)
            {
                if (KZInput.ConsumeInteract())
                {
                    Action callback = pageClosed;
                    pageTitle = null;
                    pageBody = null;
                    pageClosed = null;
                    if (callback != null) callback();
                }
                return;
            }

            if (puzzleOpen)
            {
                if (KZInput.ConsumeInteract())
                {
                    puzzleOpen = false;
                    return;
                }
                if (KZInput.Number(1))
                    puzzleFeedback = "一排七座必须留空，不能安排观众。";
                if (KZInput.Number(0)) puzzle.Cycle(0);
                if (KZInput.Number(2)) puzzle.Cycle(2);
                if (KZInput.Confirm())
                {
                    KZSeatPuzzle.Result result = puzzle.Check(cluesKnown != null && cluesKnown());
                    switch (result)
                    {
                        case KZSeatPuzzle.Result.MissingClues:
                            puzzleFeedback = "还缺少关键证据：请查看宣传册、旧合照、票根。";
                            break;
                        case KZSeatPuzzle.Result.Incomplete:
                            puzzleFeedback = "还有位置未填写；按数字1和3切换人物。";
                            break;
                        case KZSeatPuzzle.Result.Incorrect:
                            puzzleFeedback = "座次与已有线索不符，可以继续修改。";
                            break;
                        case KZSeatPuzzle.Result.Correct:
                            puzzleOpen = false;
                            Action callback = puzzleSolved;
                            puzzleSolved = null;
                            if (callback != null) callback();
                            break;
                    }
                }
                return;
            }

            if (KZInput.Journal()) journalOpen = !journalOpen;
            if (journalOpen && (KZInput.ConsumeInteract() || KZInput.Escape()))
                journalOpen = false;
        }

        private void OnGUI()
        {
            GUIStyle label = new GUIStyle(GUI.skin.label)
            {
                wordWrap = true, fontSize = 16, alignment = TextAnchor.UpperLeft
            };
            GUIStyle head = new GUIStyle(GUI.skin.label)
            {
                wordWrap = true, fontSize = 21, fontStyle = FontStyle.Bold
            };

            GUI.Box(new Rect(14f, 14f, Mathf.Min(650f, Screen.width - 28f), 102f), "");
            GUI.Label(new Rect(28f, 22f, Screen.width - 60f, 30f), chapterName, head);
            string objective = KZStoryDirector.Current == null
                ? "等待关卡逻辑" : KZStoryDirector.Current.Objective;
            GUI.Label(new Rect(28f, 54f, Screen.width - 60f, 55f), "当前目标：" + objective, label);

            if (pageTitle != null)
            {
                float w = Mathf.Min(760f, Screen.width - 40f);
                float h = Mathf.Max(160f, Mathf.Min(460f, Screen.height - 140f));
                Rect area = new Rect((Screen.width - w) * .5f, (Screen.height - h) * .5f, w, h);
                GUI.Box(area, "");
                GUILayout.BeginArea(new Rect(area.x + 24f, area.y + 20f, area.width - 48f, area.height - 40f));
                GUILayout.Label(pageTitle, head);
                scroll = GUILayout.BeginScrollView(scroll);
                GUILayout.Label(pageBody, label);
                GUILayout.EndScrollView();
                GUILayout.FlexibleSpace();
                GUILayout.Label("按 E 收起文档／继续", label);
                GUILayout.EndArea();
            }
            else if (puzzleOpen)
            {
                float w = Mathf.Min(760f, Screen.width - 40f);
                float h = Mathf.Max(160f, Mathf.Min(440f, Screen.height - 140f));
                Rect area = new Rect((Screen.width - w) * .5f, (Screen.height - h) * .5f, w, h);
                GUI.Box(area, "");
                GUILayout.BeginArea(new Rect(area.x + 24f, area.y + 18f, area.width - 48f, area.height - 36f));
                GUILayout.Label("座次复原（可替换规则样例）", head);
                GUILayout.Space(12f);
                GUILayout.Label("一排六座 [按1切换]：" + puzzle.Seat6, label);
                GUILayout.Label("一排七座 [按2尝试]：" + puzzle.Seat7, label);
                GUILayout.Label("一排八座 [按3切换]：" + puzzle.Seat8, label);
                GUILayout.Space(12f);
                GUILayout.Label("请依据已读票根安排观众甲与观众乙。" +
                    "\n一排七座必须留空，且同一观众不能出现在两张椅子上。", label);
                GUILayout.Space(12f);
                GUILayout.Label(puzzleFeedback, label);
                GUILayout.FlexibleSpace();
                GUILayout.Label("Enter 提交判定 · E 返回现场", label);
                GUILayout.EndArea();
            }
            else if (journalOpen)
            {
                float w = Mathf.Min(620f, Screen.width - 36f);
                float h = Mathf.Max(160f, Mathf.Min(440f, Screen.height - 140f));
                Rect area = new Rect(Screen.width - w - 16f, 132f, w, h);
                GUI.Box(area, "");
                GUILayout.BeginArea(new Rect(area.x + 20f, area.y + 18f, area.width - 40f, area.height - 36f));
                GUILayout.Label("调查笔记", head);
                GUILayout.Label(CollectedClues(), label);
                GUILayout.FlexibleSpace();
                GUILayout.Label("Tab／E／Esc 收起", label);
                GUILayout.EndArea();
            }
            else
            {
                if (!string.IsNullOrWhiteSpace(hint))
                {
                    float w = Mathf.Min(410f, Screen.width - 24f);
                    GUI.Box(new Rect((Screen.width - w) * .5f, Screen.height - 128f, w, 45f), hint);
                }
                GUI.Label(new Rect(Screen.width * .5f - 7f, Screen.height * .5f - 12f, 18f, 22f), "+");
            }

            if (Time.unscaledTime < toastUntil && !string.IsNullOrEmpty(toast))
            {
                float w = Mathf.Min(950f, Screen.width - 30f);
                GUI.Box(new Rect((Screen.width - w) * .5f, Screen.height - 74f, w, 57f), toast);
            }
            GUI.Label(new Rect(18f, Screen.height - 25f, Screen.width - 30f, 23f),
                "WASD 移动  ·  鼠标观察  ·  E 调查/关闭  ·  Tab 笔记  ·  Esc 鼠标释放/捕获");
        }

        private static string CollectedClues()
        {
            KZGameSession s = KZGameSession.EnsureExists();
            string result = "";
            if (s.HasFlag(KZFlags.Worksheet)) result += "• 资产清点表：明早施工，今晚务必完成。\n\n";
            if (s.HasFlag(KZFlags.Phone)) result += "• 电话：何文斌提醒后台危险，只登记数量。\n\n";
            if (s.HasFlag(KZFlags.Seat)) result += "• 第一排七座：椅面比其他位置干净。\n\n";
            if (s.HasFlag(KZFlags.Register)) result += "• 1992座位登记表：一排七座——空。\n\n";
            if (s.HasFlag(KZFlags.Program)) result += "• 节目单：1992年7月17日，周明生留座戏。\n\n";
            if (s.HasFlag(KZFlags.Ritual)) result += "• 留座戏：亡者留座，戏散前不得取遗物。\n\n";
            if (s.HasFlag(KZFlags.Photo)) result += "• 旧合照背面：周明生，1972—1992。\n\n";
            if (s.HasFlag(KZFlags.Ticket)) result += "• 票根：可与座次表核对。\n\n";
            if (s.HasFlag(KZFlags.PuzzleSolved)) result += "• 座次图：一排七座必须留空。\n\n";
            if (s.HasFlag(KZFlags.EchoFinished)) result += "• 残响：女子在空座坐下，拿走钥匙。\n\n";
            return result.Length == 0 ? "暂时没有记录。" : result;
        }
    }
}
